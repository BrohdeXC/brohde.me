Welcome to the SOC Learning-Linux CTF!
There are 20 flags hidden throughout this directory, your goal is to find them all!
All flags follow this structure: ClubCTF{5f4dcc3b5aa765d61d8327deb882cf99} 
They all use VALID HEXADECIMAL format

You will be testing your Linux terminal knowledge in many ways here. From simply reading a file to password protected zip folders, you will likely need to do research in order to find all the flags!

Hint: Some of the files might have information that can help out on other flags

Good Luck!
