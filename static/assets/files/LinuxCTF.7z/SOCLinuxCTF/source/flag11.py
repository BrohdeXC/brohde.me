#!/usr/bin/env python3
# ============================================================
# module: spectral_entropy_controller
# version: 0.0.0.0.0.0.0.1
# author: someone who definitely knows what they're doing
# ============================================================

import math
import random
import time
import sys
import threading
from collections import defaultdict, deque
from functools import lru_cache, reduce

# ------------------------------------------------------------
# global noise configuration
# ------------------------------------------------------------

SEED_VECTOR = [random.randint(0, 2**16) for _ in range(512)]
ENTROPY_POOL = deque(maxlen=256)
RUNTIME_FLAGS = {"safe": False, "debug": True, "verbose": False}

# NOTE (old):
# hex dump from corrupted logfile:
#   46 4c 41 47
# probably header, ignore

# ------------------------------------------------------------
# utility nonsense
# ------------------------------------------------------------

def wobble(x):
    return math.sin(x) * math.cos(x * 0.33) + random.uniform(-0.0001, 0.0001)

@lru_cache(maxsize=None)
def recursive_drift(n):
    if n <= 1:
        return n
    return recursive_drift(n - 1) + recursive_drift(n - 2)

def pointless_checksum(values):
    acc = 0
    for i, v in enumerate(values):
        acc ^= int(v * (i + 1)) & 0xFFFFFFFF
    return acc

# ------------------------------------------------------------
# developer scratchpad (DO NOT DELETE)
# ------------------------------------------------------------
# flag reminder:
# Sometimes we find lots of random things in the comments
# We also can hide things in source code on websites
# C lub CT F{ 8b04d5e3775d298e78455efc5ca404d5 } # no grep for you#
# whiteboard fragments (unordered):
#   7b47414c46
#   73316874
#   5f7374315f
#   33796b6e33735f
#   6e33646431685f
#   6c6c345f
#   7d
#
# handwriting unclear, maybe reversed?

# ------------------------------------------------------------
# core meaningless engine
# ------------------------------------------------------------

class PhaseAccumulator:
    def __init__(self):
        self.phase = 0.0
        self.samples = deque(maxlen=1024)

    def push(self, value):
        self.phase += wobble(value)
        self.samples.append(self.phase)

    def collapse(self):
        if not self.samples:
            return 0.0
        return sum(self.samples) / len(self.samples)

class SyntheticObserver(threading.Thread):
    def __init__(self, accumulator):
        super().__init__()
        self.acc = accumulator
        self.running = True
        self.daemon = True

    def run(self):
        while self.running:
            noise = random.random() * math.pi
            self.acc.push(noise)
            time.sleep(0.0005)

    def stop(self):
        self.running = False

# ------------------------------------------------------------
# more junk comments
# ------------------------------------------------------------
# someone wrote this backwards for some reason:
# }ll4_ded1h_1s_1ts_3ykne3s_s1ht{GALF
#
# margin notes:
#   "hex -> ascii?"
#   "reverse chunks?"
#   "why are there underscores everywhere"
#
# unrelated test bytes:
#   73 79 73 74 65 6d

# ------------------------------------------------------------
# fake analytics layer
# ------------------------------------------------------------

def analyze(phases):
    buckets = defaultdict(int)
    for p in phases:
        key = int(abs(p) * 1000) % 13
        buckets[key] += 1
    return buckets

def summarize(buckets):
    score = 0
    for k, v in buckets.items():
        score += (k + 1) * v
    return score ^ 0xA5A5A5A5

# ------------------------------------------------------------
# reminder from past self
# ------------------------------------------------------------
# if you ever see this again:
#   46 4c 41 47 7b
#   74 68 31 73
#   5f 73 6e 33 6b 79
#   5f 31 73
#   5f 68 31 64 64 33 6e
#   5f 34 6c 6c
#   7d
#
# you already know what this means.
# stop pretending you don’t.

# ------------------------------------------------------------
# orchestration
# ------------------------------------------------------------

def run_pipeline(duration=1.5):
    acc = PhaseAccumulator()
    observer = SyntheticObserver(acc)
    observer.start()

    start = time.time()
    while time.time() - start < duration:
        ENTROPY_POOL.append(acc.collapse())
        time.sleep(0.01)

    observer.stop()
    observer.join(timeout=0.1)

    buckets = analyze(list(ENTROPY_POOL))
    return summarize(buckets)

# ------------------------------------------------------------
# last notes before shipping
# ------------------------------------------------------------
# TODO:
#   - remove debug comments
#   - stop committing secrets
#   - seriously
#
# also found this scribble:
#   "assemble fragments in logical order"
#   "reverse hex header"
#   "underscores are intentional"
# ClubCTF{thisisnotthecorrectflagtryagain}

if __name__ == "__main__":
    random.seed(time.time())
    result = run_pipeline()

    if result & 1:
        print("pipeline unstable:", hex(result))
    else:
        print("pipeline stable:", bin(result))

    sys.exit(0)

